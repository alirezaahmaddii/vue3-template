# Vue3 + Typescript + Vuetify

You should use Node version +18
