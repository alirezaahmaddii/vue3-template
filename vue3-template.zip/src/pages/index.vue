<template>
  <HelloWorld />
</template>

<script lang="ts" setup>
const hello = "test";
console.log(hello)
</script>
