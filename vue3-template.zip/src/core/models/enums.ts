export enum Example {
    Up = 1,
    Down,
    Left,
    Right,
  }
