export type TypeEx = {
    name: string
}
