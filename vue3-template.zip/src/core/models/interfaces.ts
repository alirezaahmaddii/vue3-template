export interface IData {
    name: string
}
